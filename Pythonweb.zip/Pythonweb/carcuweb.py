from flask import Flask, render_template, request
from pyparsing import *
import re

# Clase para representar un nodo en el árbol
class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
        self.x = 0
        self.y = 0

    def __str__(self):
        return str(self.value)

    def to_dict(self):
        return {
            'value': self.value,
            'left': self.left.to_dict() if self.left else None,
            'right': self.right.to_dict() if self.right else None,
            'x': self.x,
            'y': self.y
        }

# Función para construir el árbol de operaciones y asignar coordenadas a los nodos
def build_tree(tokens, x=0, y=0):
    if len(tokens) == 1:
        return Node(tokens[0])
    elif len(tokens) == 3:
        node = Node(tokens[1])
        node.left = build_tree(tokens[0], x - 50, y + 100)
        node.right = build_tree(tokens[2], x + 50, y + 100)
        node.x = x
        node.y = y
        return node
    else:
        index = len(tokens) // 2
        node = Node(tokens[index])
        if index > 0:
            node.left = build_tree(tokens[:index], x - 50 / (index + 1), y + 100)
        if index < len(tokens) - 1:
            node.right = build_tree(tokens[index+1:], x + 50 / (len(tokens) - index), y + 100)
        node.x = x
        node.y = y
        return node

# Analizador Léxico
def analizador_lexico(expresion):
    # Utilizamos una expresión regular para dividir la expresión en tokens
    # La expresión regular busca números, operadores y paréntesis como tokens individuales
    tokens = re.findall(r'\d+\.?\d*|\+|\-|\*|\/|\(|\)', expresion)
    return tokens

# Analizador Sintáctico
def analizador_sintactico(tokens):
    for token in tokens:
        if not grammar.parseString(token):
            return False
    return True

# Define la gramática de la calculadora
integer = Word(nums)
operand = Word(nums) | '+' | '-' | '*' | '/'
parenthesis = Literal('(') | Literal(')')
grammar = OneOrMore(operand | parenthesis)

# Crea la aplicación Flask
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def calculator():
    expression = ""
    result = ""
    tree = ""
    tokens = ""
    is_valid = ""
    if request.method == 'POST':
        expression = request.form.get('expression')
        
        # Análisis Léxico
        tokens = analizador_lexico(expression)
        
        # Análisis Sintáctico
        if not analizador_sintactico(tokens):
            result = "Error: Expresión inválida"
            tree = ""
            is_valid = "No"
        else:
            try:
                parsed = grammar.parseString(expression)
                result = str(eval(expression))
                tree = build_tree(tokens).to_dict()
                is_valid = "Sí"
            except Exception as e:
                result = "Error: " + str(e)
                tree = ""
                is_valid = "No"

    return render_template('calculator.html', expression=expression, result=result, tree=tree, tokens=tokens, is_valid=is_valid)

if __name__ == '__main__':
    app.run(debug=True)
