// calculator.js

// Función para agregar dígitos al campo de entrada
function addToDisplay(value) {
    const display = document.calculator.ans;
    display.value += value;
}

// Función para borrar el contenido del campo de entrada
function clearDisplay() {
    const display = document.calculator.ans;
    display.value = '';
}
